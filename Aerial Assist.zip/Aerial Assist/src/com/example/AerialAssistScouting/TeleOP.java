package com.example.AerialAssistScouting;

import java.util.ArrayList;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.app.NavUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.example.scoutingapp610.R;

public class TeleOP extends Activity {
	// Declare static Score object
	static Score scoutingTeam;
	// Declare static cycleNumber
	static int cycleNumber;
	// Declare goal value
	int goalValue;
	// Declare highMiss and lowMiss variables
	int highMiss, lowMiss;
	// Declare Button objects
	Button goalBlockIncrement, goalBlockDecrement, missClickUp, missClickDown;
	// Declare ToggleButton objects
	ToggleButton noGoal, lowGoal, highGoal;
	ToggleButton catchOnToggle, trussOnToggle, assistOnToggle;
	// Declare dialog object
	AlertDialog.Builder dialog;
	// Declare TextView objects
	TextView missCounterLow, missCounterHigh, goalBlock;
	// Declare Intent object (for going to next page)
	Intent goToNextPage;
	// Declare Vibrate object
	Vibrator vibrate;
	// Declare LinearLayout object
	LinearLayout list;
	// Create array list of CycleList objects
	ArrayList<CycleList> cycles;
	// Vibrate length constant
	final int VIBRATE_LENGTH = 90;
	// Create a temporary object that points to THIS activity
	Context temp = this;
	// Create static instance of THIS class
	static TeleOP instance;

	// EditText timerString;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tele_op);
		// Show the Up button in the action bar.
		setupActionBar();
		// Assign LinearLayout object to its assigned ID
		list = (LinearLayout) findViewById(R.id.cycleList);
		// Populate cycles
		populateCycles();
		instance = this;
		// Get current Score instance
		scoutingTeam = Score.getInstance();
		// Create dialog
		dialog = new AlertDialog.Builder(this);
		// Create vibrator
		vibrate = (Vibrator) getSystemService(VIBRATOR_SERVICE);
		// Set defualt goalValue and cycleNumber to 0
		goalValue = 0;
		cycleNumber = 0;
		// Assign Button objects to their assigned IDs
		missClickUp = (Button) findViewById(R.id.missUp);
		missClickDown = (Button) findViewById(R.id.missDown);
		// Assign ToggleButton objects to their assigned IDs
		noGoal = (ToggleButton) findViewById(R.id.noScore);
		lowGoal = (ToggleButton) findViewById(R.id.lowGoal);
		highGoal = (ToggleButton) findViewById(R.id.highGoal);
		catchOnToggle = (ToggleButton) findViewById(R.id.catchOnToggle);
		assistOnToggle = (ToggleButton) findViewById(R.id.assistOnToggle);
		trussOnToggle = (ToggleButton) findViewById(R.id.trussOnToggle);
		// Assign TextView objects to their assigned IDs
		missCounterLow = (TextView) findViewById(R.id.missCountLow);
		missCounterHigh = (TextView) findViewById(R.id.missCountHigh);
		goalBlock = (TextView) findViewById(R.id.goalBlock);
		// Make missClick buttons invisible
		missClickUp.setVisibility(View.INVISIBLE);
		missClickDown.setVisibility(View.INVISIBLE);
		// Set the default checked for noGoal to true and set it to green
		noGoal.setBackgroundColor(Color.GREEN);
		noGoal.setChecked(true);
		// Set high and low goal toggle buttons to red
		lowGoal.setBackgroundColor(Color.RED);
		highGoal.setBackgroundColor(Color.RED);
		// Set all of these toggle buttons to red
		assistOnToggle.setBackgroundColor(Color.RED);
		catchOnToggle.setBackgroundColor(Color.RED);
		trussOnToggle.setBackgroundColor(Color.RED);
		// Assign object for goToNextPage
		goToNextPage = new Intent(this, SubmitPage.class);
	}

	/**
	 * Set up the {@link android.app.ActionBar}, if the API is available.
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	private void setupActionBar() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			getActionBar().setDisplayHomeAsUpEnabled(true);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.tele_o, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// This ID represents the Home or Up button. In the case of this
			// activity, the Up button is shown. Use NavUtils to allow users
			// to navigate up one level in the application structure. For
			// more details, see the Navigation pattern on Android Design:
			//
			// http://developer.android.com/design/patterns/navigation.html#up-vs-back
			//
			// NavUtils.navigateUpFromSameTask(this);
			list.removeAllViews();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	// If back button is pressed...
	@Override
	public void onBackPressed() {
		// Remove all CycleLists from view
		list.removeAllViews();
		// Go back
		super.onBackPressed();
	}

	// Get current instance
	public static TeleOP getInstance() {
		return instance;
	}

	// When noGoal button is clicked...
	public void noGoalClick(View v) {
		// Vibrate for specific length
		vibrate.vibrate(VIBRATE_LENGTH);
		// Set this toggle button to true
		noGoal.setChecked(true);
		// Set color to green
		noGoal.setBackgroundColor(Color.GREEN);
		// Set other score toggle buttons to red
		lowGoal.setBackgroundColor(Color.RED);
		highGoal.setBackgroundColor(Color.RED);
		// Make the missClick buttons invisible
		missClickUp.setVisibility(View.INVISIBLE);
		missClickDown.setVisibility(View.INVISIBLE);
		// Set goalValue to 0
		goalValue = 0;
		// Set lowGoal and highGoal toggle buttons to false
		lowGoal.setChecked(false);
		highGoal.setChecked(false);
		// Set text for newCycle button to "New Cycle"
		((Button) findViewById(R.id.cycleButton)).setText("New Cycle");

	}

	// If the lowGoal button is clicked...
	public void lowGoalClick(View v) {
		// Vibrate for specific length
		vibrate.vibrate(VIBRATE_LENGTH);
		// Set this toggle button to true
		lowGoal.setChecked(true);
		// Set goalValue to 1
		goalValue = 1;
		// Set noGoal toggle button to red
		noGoal.setBackgroundColor(Color.RED);
		// Set lowGoal toggle button to green
		lowGoal.setBackgroundColor(Color.GREEN);
		// Set highGoal toggleButton to red
		highGoal.setBackgroundColor(Color.RED);
		// Set noGoal and highGoal toggle buttons to false
		noGoal.setChecked(false);
		highGoal.setChecked(false);
		// Make the missClick buttons visible
		missClickUp.setVisibility(View.VISIBLE);
		missClickDown.setVisibility(View.VISIBLE);
		// Set text for newCycle button to "Score"
		((Button) findViewById(R.id.cycleButton)).setText("Score");
	}

	// If the highGoal button is clicked...
	public void highGoalClick(View v) {
		// Vibrate for specific length
		vibrate.vibrate(VIBRATE_LENGTH);
		// Set this toggle button to true
		highGoal.setChecked(true);
		// Set goalValue to 10
		goalValue = 10;
		// Set noGoal and lowGoal toggle buttons to red
		noGoal.setBackgroundColor(Color.RED);
		lowGoal.setBackgroundColor(Color.RED);
		// Set highGoal toggle button to green
		highGoal.setBackgroundColor(Color.GREEN);
		// Set noGoal and lowGoal toggle buttons to false
		noGoal.setChecked(false);
		lowGoal.setChecked(false);
		// Make the missClick buttons visible
		missClickUp.setVisibility(View.VISIBLE);
		missClickDown.setVisibility(View.VISIBLE);
		// Set text for newCycle button to "Score"
		((Button) findViewById(R.id.cycleButton)).setText("Score");
	}

	// If catch button is clicked...
	public void catchOnClick(View v) {
		// Vibrate for specific length
		vibrate.vibrate(VIBRATE_LENGTH);
		// Depending on the catchOnToggle state, change the colour
		if (catchOnToggle.isChecked()) {
			// Set toggle button colour to green if toggle button is true
			catchOnToggle.setBackgroundColor(Color.GREEN);
		} else {
			// Set toggle button colour to red if toggle button is false
			catchOnToggle.setBackgroundColor(Color.RED);
		}
	}

	// If assist button is clicked...
	public void assistOnClick(View v) {
		// Vibrate for specific length
		vibrate.vibrate(VIBRATE_LENGTH);
		// Depending on the assistOnToggle state, change the colour
		if (assistOnToggle.isChecked()) {
			// Set toggle button colour to green if toggle button is true
			assistOnToggle.setBackgroundColor(Color.GREEN);
		} else {
			// Set toggle button colour to red if toggle button is false
			assistOnToggle.setBackgroundColor(Color.RED);
		}
	}

	// If truss button is clicked
	public void trussOnClick(View v) {
		// Vibrate for specific length
		vibrate.vibrate(VIBRATE_LENGTH);
		// Depending on the trussOnToggle state, change the colour
		if (trussOnToggle.isChecked()) {
			// Set toggle button colour to green if toggle button is true
			trussOnToggle.setBackgroundColor(Color.GREEN);
		} else {
			// Set toggle button colour to red if toggle button is false
			trussOnToggle.setBackgroundColor(Color.RED);
		}
	}

	// If goalBlockIncrement is clicked...
	public void goalBlockIncrement(View v) {
		// Vibrate for specific length
		vibrate.vibrate(VIBRATE_LENGTH);
		// Call goalBlockIncrement method in Score class
		scoutingTeam.goalBlockIncrement();
		// Set goalBlock text
		goalBlock.setText("Goals Blocked: " + scoutingTeam.getGoalBlock());
	}

	// If goalBlockDecrement is clicked
	public void goalBlockDecrement(View v) {
		// Vibrate for specific length
		vibrate.vibrate(VIBRATE_LENGTH);
		// Call goalBlickDecrement method in Score class
		scoutingTeam.goalBlockDecrement();
		// Set goalBlock text
		goalBlock.setText("Goals Blocked: " + scoutingTeam.getGoalBlock());
	}

	// If newCycle button is clicked...
	public void newCycle(View v) {
		// Vibrate for specific length
		vibrate.vibrate(VIBRATE_LENGTH);
		// If nothing is changed...
		if (noGoal.isChecked() && !catchOnToggle.isChecked()
				&& !trussOnToggle.isChecked() && !assistOnToggle.isChecked()) {
			// Show error message
			dialog.setCancelable(true);
			dialog.setTitle("No Input Entered");
			dialog.setMessage("Robot did not score, shoot over Truss, assist, or catch.  Only enter cycles where the robot does 1 or more of the above.");
			dialog.show();
			// If something is changed...
		} else {

			// Increase cycleNumber
			cycleNumber++;
			// Increment saved score by goalValue
			scoutingTeam.score(goalValue);
			// Increment goal counter by 1
			scoutingTeam.goalLocation(goalValue, 1);
			// If assistOnToggle is true
			if (assistOnToggle.isChecked()) {
				// Increment assist counter by 1
				scoutingTeam.assist(1);
			}
			// If catchOnToggle is true
			if (catchOnToggle.isChecked()) {
				// Increment catches counter by 1
				scoutingTeam.catches(1);
				// Increment saved score by 10
				scoutingTeam.score(10);
			}
			// If trussOnToggle is true
			if (trussOnToggle.isChecked()) {
				// Increment trussGoal counter by 1
				scoutingTeam.trussGoals(1);
				// Increment saved score by 10
				scoutingTeam.score(10);
			}
			// Create new CycleList object
			new CycleList(temp, list, highMiss, lowMiss, goalValue,
					assistOnToggle.isChecked(), trussOnToggle.isChecked(),
					catchOnToggle.isChecked());
			// Reset all values
			highMiss = 0;
			lowMiss = 0;
			// Set noGoal to true
			noGoal.setChecked(true);
			// Set lowGoal and highGoal to false
			lowGoal.setChecked(false);
			highGoal.setChecked(false);
			// Set all toggles to false
			assistOnToggle.setChecked(false);
			trussOnToggle.setChecked(false);
			catchOnToggle.setChecked(false);
			// Set noGoal toggle button colour to green
			noGoal.setBackgroundColor(Color.GREEN);
			// Set lowGoal and highGoal toggle button colour to red
			lowGoal.setBackgroundColor(Color.RED);
			highGoal.setBackgroundColor(Color.RED);
			// Set truss toggle, assist toggle, and catch toggle to red
			trussOnToggle.setBackgroundColor(Color.RED);
			assistOnToggle.setBackgroundColor(Color.RED);
			catchOnToggle.setBackgroundColor(Color.RED);
			// Make missClick buttons invisible
			missClickUp.setVisibility(View.INVISIBLE);
			missClickDown.setVisibility(View.INVISIBLE);
			// Reset missCounter text
			missCounterLow.setText("Low Miss: " + lowMiss);
			missCounterHigh.setText("High Miss: " + highMiss);
			// Set goalValue to 0
			goalValue = 0;
		}
	}

	// If missUpClick button is clicked...
	public void missUpClick(View v) {
		// Vibrate for specific length
		vibrate.vibrate(VIBRATE_LENGTH);
		// Increment miss counter in scoutingTeam object
		scoutingTeam.missIncrement(goalValue);
		// If goalValue is 1
		if (goalValue == 1) {
			// Increment lowMiss variable
			lowMiss++;
			// Set missCounterLow text
			missCounterLow.setText("Low Miss: " + lowMiss);
		} else {
			// Increment highMiss variable
			highMiss++;
			// Set missCounterHigh text
			missCounterHigh.setText("High Miss: " + highMiss);
		}
	}

	// If missDownClick button is clicked
	public void missDownClick(View v) {
		// Vibrate for specific length
		vibrate.vibrate(VIBRATE_LENGTH - 15);
		// If goalValue is 1...
		if (goalValue == 1) {
			// If lowMiss value is not 0...
			if (lowMiss != 0) {
				// Decrement lowMiss
				lowMiss--;
				// Decrement lowMiss in scoutingTeam object
				scoutingTeam.missDecrement(goalValue);
			}
			// Set missCounterLow text
			missCounterLow.setText("Low Miss: " + lowMiss);
		} else {
			// If highMiss value is not 0...
			if (highMiss != 0) {
				// Decrement highMiss
				highMiss--;
				// Decrement highMiss in scoutingTeam object
				scoutingTeam.missDecrement(goalValue);
			}
			// Set missCounterHigh text
			missCounterHigh.setText("High Miss: " + highMiss);
		}
	}

	// If nextPage button is clicked...
	public void nextPage(View v) {
		// Vibrate for specific length
		vibrate.vibrate(VIBRATE_LENGTH);
		// Display confirm message
		dialog.setTitle("Confirm");
		dialog.setMessage("Submit Tele-Op Data?");
		// Create positive button with text "Yes"
		dialog.setPositiveButton("Yes", new OnClickListener() {
			// If positive button is clicked...
			public void onClick(DialogInterface dialog, int which) {
				// Set cycleNumber
				scoutingTeam.setCycle(cycleNumber);
				// Go to next activity (SubmitPage)
				startActivity(goToNextPage);
			}
		});
		// Create negative button with text "No"
		dialog.setNegativeButton("No", null);
		dialog.show();

	}

	// Delete specific cycle
	public static void deleteCycle(CycleList c) {
		// Decrement goalLocation counter for the goal scored in deleted cycle
		scoutingTeam.goalLocation(c.getGoalLocation(), -1);
		// Decrement saved score
		scoutingTeam.score(-c.getGoalLocation());
		// If robot caught ball in the deleted cycle...
		if (c.isCatched()) {
			// Decrement catches counter by 1
			scoutingTeam.catches(-1);
			// Decrement saved score by 10
			scoutingTeam.score(-10);
		}
		// If robot scored trussGoal in the deleted cycle...
		if (c.isTrussGoal()) {
			// Decrement trussGoals counter by 1
			scoutingTeam.trussGoals(-1);
			// Decrement saved score by 10
			scoutingTeam.score(-10);
		}
		// If robot assisted in the deleted cycle...
		if (c.isAssist()) {
			// Decrement assist counter
			scoutingTeam.assist(-1);
		}
		// Decrement miss counters if misses where recorded in deleted cycle
		scoutingTeam.missDecrement(10, c.getHighMiss());
		scoutingTeam.missDecrement(1, c.getLowMiss());
		// Decrement cycleNumber
		cycleNumber--;
		// Remove it from the ArrayList
		Score.getList().remove(c);
	}

	// Method that gets and displays all CycleList objects
	public void populateCycles() {
		list = (LinearLayout) findViewById(R.id.cycleList);
		for (CycleList cL : Score.getList()) {
			list.addView(cL);
		}
	}

	// Remove all CycleLists from view
	public void emptyCycles() {
		list.removeAllViews();
	}

}
