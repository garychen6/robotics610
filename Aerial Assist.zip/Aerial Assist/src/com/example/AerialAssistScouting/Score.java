package com.example.AerialAssistScouting;

import java.io.Serializable;
import java.util.ArrayList;

public class Score implements Serializable {
	int matchNum=0, teamNumber=0;
	String comments, name;  // dont need comments
	int highGoal=0, lowGoal=0;
	int autonHigh=0, autonLow=0;
	int goalBlock=0;
	boolean autonNoGoal = false;
	boolean autonScored=false, autonMissed=false;
	boolean intake=false,herder=false,shooter=false,catcher=false,goalie=false; // dont need robot type on final page
	int highMiss=0, lowMiss=0;
	int personalScore=0, autonScore=0, assist=0, catches=0, trussGoals=0, cycle=0; // dont need personal score on final page
	int defenceRating=0;
	boolean mobility=false, hotGoal=false, goalieStart=false;
	boolean noShow=false;
	static Score instance = null;
	static ArrayList<CycleList> list = new ArrayList<CycleList>();

	public static Score getInstance() {
		if (instance == null) {
			instance = new Score();
		}
		return instance;
	}

	public Score() {
	}

	// Set team number string
	public void setTeamNumber(int teamNumber) {
		this.teamNumber = teamNumber;
	}
	//Set match number
	public void matchNumber(int num) {
		matchNum = num;
	}

	// Set total auton score
	public void setAutonScore(int autonScore) {
		this.autonScore = autonScore;
	}
	public void autonMissed(boolean miss){
		autonMissed = miss;
	}
	public void autonScored(boolean scored){
		autonScored = scored;
	}

	// Set auton shot location
	public void autonShotLocation(int goal) {
		if (goal == 0) {
			autonNoGoal = true;
		} else if (goal == 6) {
			autonLow++;
		} else {
			autonHigh++;
		}
	}

	// Set if robot shot hotgoal in auton;
	public void autonHotGoal(boolean hotGoal) {
		this.hotGoal = hotGoal;
	}

	public void mobility(boolean mobility) {
		this.mobility = mobility;
	}

	public void goalieStart(boolean start) {
		goalieStart = start;
	}

	// Add to score
	public void score(int goal) {
		personalScore += goal;
	}

	// Increment or decrement goal locations
	public void goalLocation(int goal, int value) {
		if (goal == 1) {
			lowGoal += value;
		} else if(goal == 10){
			highGoal += value;
		}
	}

	public void missIncrement(int goal) {
		if (goal == 1) {
			lowMiss++;
		} else {
			highMiss++;
		}
	}

	public void missDecrement(int goal) {
		if (goal == 1) {
			if (lowMiss != 0) {
				lowMiss--;
			}
		} else {
			if (highMiss != 0) {
				highMiss--;
			}
		}
	}
	public void missDecrement(int goal, int value) {
		if (goal == 1) {
			if (lowMiss != 0) {
				lowMiss -= value;
			}
		} else {
			if (highMiss != 0) {
				highMiss -= value;
			}
		}
	}

	// Increment or decrement assist counter
	public void assist(int value) {
		assist += value;

	}

	// Increment or decrement truss goal counter
	public void trussGoals(int value) {
		trussGoals += value;
	}

	// Increment or decrement catch counter
	public void catches(int value) {
		catches += value;
	}

	public void setCycle(int cycle){
		this.cycle = cycle;
	}
	public void goalBlockIncrement(){
		goalBlock++;
	}
	public void goalBlockDecrement(){
		if(goalBlock > 0){
			goalBlock--;
		}
	}
	public void addDefenceRating(int rating) {
		defenceRating = rating;
	}
	public void setGoalie(boolean goalie){
		this.goalie = goalie;
	}
	public void setShooter(boolean shooter){
		this.shooter = shooter;
	}
	public void setIntake(boolean intake){
		this.intake = intake;
	}
	public void setHerder(boolean herder){
		this.herder = herder;
	}
	public void setCatcher(boolean catcher){
		this.catcher = catcher;
	}
	
	
	
	
	
	public int getBlockedGoals(){
		return goalBlock;
	}
	
	public int getHighGoal(){
		return highGoal;
	}
	public int getLowGoal(){
		return lowGoal;
	}
	public int getHighMiss(){
		return highMiss;
	}
	public int getLowMiss(){
		return lowMiss;
	}
	
	public boolean getCatcher(){
		return catcher;
	}
	public boolean getHerder(){
		return herder;
	}
	public boolean getShooter(){
		return shooter;
	}
	public boolean getIntake(){
		return intake;
	}
	public boolean getGoalie(){
		return goalie;
	}

	public int getAutonScore(){
		return autonScore;
	}
	public int getMatchNum(){
		return matchNum;
	}
	public int getAutonLowGoals(){
		return autonLow;
	}
	public int getAutonHighGoals(){
		return autonHigh;
	}
	
	public boolean getMobility(){
		return mobility;
	}
	public boolean getHotGoal(){
		return hotGoal;
	}
	public boolean getGoalieStart(){
		return goalieStart;
	}

	public int getTeamNumber() {
		return teamNumber;
	}

	public String getName() {
		return name;
	}

	public int getMissCounter(int goal) {
		if (goal == 1) {
			return lowMiss;
		} else {
			return highMiss;
		}
	}
	public int getGoalBlock(){
		return goalBlock;
	}

	// Reset instance when called
	public static void reset() {
		list.clear();
		instance = null;
	}

	public String getComments() {
		return comments;
	}

	public int getAutonHigh() {
		return autonHigh;
	}

	public int getAutonLow() {
		return autonLow;
	}

	public boolean isAutonNoGoal() {
		return autonNoGoal;
	}

	public boolean isAutonScored() {
		return autonScored;
	}

	public boolean isAutonMissed() {
		return autonMissed;
	}

	public int getPersonalScore() {
		return personalScore;
	}

	public int getAssist() {
		return assist;
	}

	public int getCatches() {
		return catches;
	}

	public int getTrussGoals() {
		return trussGoals;
	}

	public int getCycle() {
		return cycle;
	}

	public int getDefenceRating() {
		return defenceRating;
	}
	public void setName(String name) {
		this.name = name;
	}
	public static ArrayList<CycleList> getList(){
		return list;
	}
}
