 package com.example.AerialAssistScouting;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.scoutingapp610.R;

public class FinalPage extends Activity {
	
	//Declare TextView objects
	TextView matchNumber, teamNumber, scouterName;
	TextView autonScore, autonHighGoals, autonLowGoals, autonMisses;
	TextView mobility, hotGoal, goalie, tracking;
	TextView cycles, highGoals, lowGoals, highMisses, lowMisses, assists, trussGoals, catches;
	//Declare score object
	Score score;
	//Declare linear list for cycle list display
	LinearLayout list;
	//Declare and create Intent object
	static Intent goToNextPage;
	//Declare Dialog object
	AlertDialog.Builder dialog;
	
	public static ProgressBar spinner;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		//Default Code
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_final_page);
		// Show the Up button in the action bar.
		setupActionBar();
		//Get current instance of Score object
		score = Score.getInstance();
		//Create Linear Layout object that has the ID cycleListFinal
		list = (LinearLayout) findViewById(R.id.cycleListFinal);
		TeleOP.getInstance().emptyCycles();
		//Call stats methods
		topInfoBar();
		autonStats();
		teleopStats();
		//Create Dialog object
		dialog = new AlertDialog.Builder(this);
		//For each loop that generates cycle list
		for(CycleList cL : Score.getList()){
			list.addView(cL);
			//Set the delete cycle on ever CycleList object to invisible.
			((ImageButton)findViewById(R.id.deleteCycle)).setVisibility(View.INVISIBLE);;
		}
		spinner = (ProgressBar)findViewById(R.id.progressBar1);
		goToNextPage = new Intent(this, MainActivity.class);
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);  //this is to allow the main thread to run network requests
	}
	//Set text for scouter name, team number, and match number
	public void topInfoBar(){
		matchNumber = (TextView)findViewById(R.id.matchNumber);
		matchNumber.setText("Match: " + score.getMatchNum());
		
		teamNumber = (TextView)findViewById(R.id.teamNumber);
		teamNumber.setText("Team: " + score.getTeamNumber());
		
		scouterName = (TextView)findViewById(R.id.scouterName);
		scouterName.setText("Scouter: " + score.getName());
	}
	//Set text for all auton stats.
	public void autonStats(){
		//Set text for auton score
		((TextView)findViewById(R.id.autonScore)).setText("Auton Score: " + score.getAutonScore());
		//Set text for number of auton low goals
		((TextView)findViewById(R.id.autonHighGoals)).setText("Auton Low Goals: " + score.getAutonHighGoals());
		//Set text for number of auton high goals
		((TextView)findViewById(R.id.autonLowGoals)).setText("Auton High Goals: " + score.getAutonLowGoals());
		//Color the text box red for autonMisses if the robot missed or did not shoot in auton
		if(score.isAutonMissed() || score.isAutonNoGoal()){
			((TextView)findViewById(R.id.autonMisses)).setBackgroundColor(Color.RED);
		}else{
			((TextView)findViewById(R.id.autonMisses)).setBackgroundColor(Color.GREEN);
		}
		//Color the text box red for mobility if the robot did not have a mobility score.  If not, color green
		if(score.getMobility()){
			((TextView)findViewById(R.id.mobility)).setBackgroundColor(Color.GREEN);
		}else{
			((TextView)findViewById(R.id.mobility)).setBackgroundColor(Color.RED);
		}
		//Color the text box for hotGoal if the robot did not aim at hot goal.  If not, color green.
		if(score.getHotGoal()){
			((TextView)findViewById(R.id.hotGoal)).setBackgroundColor(Color.GREEN);
		}else{
			((TextView)findViewById(R.id.hotGoal)).setBackgroundColor(Color.RED);
		}
		//Color the text box for goalieStart if the robot did not start in the goalie zone.  If not, color green
		if(score.getGoalieStart()){
			((TextView)findViewById(R.id.goalie)).setBackgroundColor(Color.GREEN);
		}else{
			((TextView)findViewById(R.id.goalie)).setBackgroundColor(Color.RED);
		}
	}
	//Set text for tele-op stats
	public void teleopStats(){
		((TextView)findViewById(R.id.cycles)).setText("Cycles: " + score.getCycle());
		((TextView)findViewById(R.id.highGoals)).setText("High Goals: " + score.getHighGoal());
		((TextView)findViewById(R.id.lowGoals)).setText("Low Goals: " + score.getLowGoal());
		((TextView)findViewById(R.id.highMisses)).setText("High Misses: " + score.getHighMiss());
		((TextView)findViewById(R.id.lowMisses)).setText("Low Misses: " + score.getLowMiss());
		((TextView)findViewById(R.id.assists)).setText("Assists: " + score.getAssist());
		((TextView)findViewById(R.id.trussGoals)).setText("Truss Goals: " + score.getTrussGoals());
		((TextView)findViewById(R.id.catches)).setText("Catches: " + score.getCatches());
		((TextView)findViewById(R.id.goalBlocked)).setText("Goals Blocked: " + score.getGoalBlock());
		
	}

	/**
	 * Set up the {@link android.app.ActionBar}, if the API is available.
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	private void setupActionBar() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			getActionBar().setDisplayHomeAsUpEnabled(true);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.final_page, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// This ID represents the Home or Up button. In the case of this
			// activity, the Up button is shown. Use NavUtils to allow users
			// to navigate up one level in the application structure. For
			// more details, see the Navigation pattern on Android Design:
			//
			// http://developer.android.com/design/patterns/navigation.html#up-vs-back
			//
			//NavUtils.navigateUpFromSameTask(this);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	//When finishButton is clicked...
	public void finish(View v){
		
		String result = PhpRequest.postScore(score);
		System.out.println(result);
		dialog.setTitle("Submit Sucessful");
		//Reset all static variables in Score class and create a new instance.
		Score.reset();
		//Go to auton page (MainActivity)
		startActivity(goToNextPage);
	}
	//If back button is pressed...
	@Override
	public void onBackPressed(){
		//Set the delete image button to visible for all CycleLists
		for(CycleList cL : score.getList()){
			((ImageButton)findViewById(R.id.deleteCycle)).setVisibility(View.VISIBLE);
		}  
		//Remove all CycleLists from view
		list.removeAllViews();
		TeleOP.getInstance().populateCycles();
		super.onBackPressed();
	}
}
