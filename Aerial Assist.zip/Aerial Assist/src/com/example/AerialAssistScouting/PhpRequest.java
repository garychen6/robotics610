package com.example.AerialAssistScouting;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.util.Log;

public class PhpRequest {

	public static String postScore(Score s) {
		long start = System.currentTimeMillis();
		ArrayList<NameValuePair> nvp = new ArrayList<NameValuePair>();
		InputStream is = null;
		StringBuilder sb;
		// http post
		try {
			HttpClient httpclient = new DefaultHttpClient();
//			HttpPost httppost = new HttpPost("http://10.0.2.2/ScoutingDatabase/sqlUpdate.php");
			HttpPost httppost = new HttpPost("http://610stats.comuv.com/sqlUpdate.php");
			httppost.setHeader("content-type", "application/x-www-form-urlencoded");
			nvp.add(new BasicNameValuePair("tournament", ""+MainActivity.tournament));
			nvp.add(new BasicNameValuePair("team_num", ""+s.teamNumber));
			nvp.add(new BasicNameValuePair("match_num", ""+s.matchNum));
			nvp.add(new BasicNameValuePair("scouter_name", s.name));
			nvp.add(new BasicNameValuePair("num_cycles", ""+s.cycle));
			nvp.add(new BasicNameValuePair("num_assist", ""+s.assist));
			nvp.add(new BasicNameValuePair("num_catches", ""+s.catches));
			nvp.add(new BasicNameValuePair("truss_goals", ""+s.trussGoals));
			nvp.add(new BasicNameValuePair("high_goal", ""+s.highGoal));
			nvp.add(new BasicNameValuePair("low_goal", ""+s.lowGoal));
			nvp.add(new BasicNameValuePair("high_goal_misses", ""+s.highMiss));
			nvp.add(new BasicNameValuePair("low_goal_misses", ""+s.lowMiss));
			nvp.add(new BasicNameValuePair("defense_rating", ""+s.defenceRating));
			nvp.add(new BasicNameValuePair("auton_high_goal", ""+(s.autonHigh>0?1:0)));
			nvp.add(new BasicNameValuePair("auton_low_goal", ""+(s.autonLow>0?1:0)));
			nvp.add(new BasicNameValuePair("auton_miss", ""+(s.autonMissed?1:0)));
			nvp.add(new BasicNameValuePair("auton_high_goal_hot", ""+(s.hotGoal?1:0)));
			nvp.add(new BasicNameValuePair("auton_no_score", ""+(s.autonNoGoal?1:0)));
			nvp.add(new BasicNameValuePair("auton_mobility", ""+(s.mobility?1:0)));
			nvp.add(new BasicNameValuePair("blocked_shots", ""+s.goalBlock));
			nvp.add(new BasicNameValuePair("start_in_goalie_zone", ""+(s.goalieStart?1:0)));
			nvp.add(new BasicNameValuePair("no_show", ""+(s.noShow?1:0)));
			nvp.add(new BasicNameValuePair("shooter", ""+(s.shooter?1:0)));
			nvp.add(new BasicNameValuePair("intake", ""+(s.intake?1:0)));
			nvp.add(new BasicNameValuePair("herder", ""+(s.herder?1:0)));
			nvp.add(new BasicNameValuePair("goalie", ""+(s.goalie?1:0)));
			nvp.add(new BasicNameValuePair("catcher", ""+(s.catcher?1:0)));
			httppost.setEntity(new UrlEncodedFormEntity(nvp));
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();
		} catch (Exception e) {
			Log.e("log_tag", "Error in http connection " + e.toString());
		}
		// convert response to string
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			sb = new StringBuilder();
			sb.append(reader.readLine() + "\n");

			String line = "0";
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();
			System.out.println("CONNECT: "+(System.currentTimeMillis() - start));
			return sb.toString();
		} catch (IOException e) {
			Log.e("log_tag", "Error converting result " + e.toString());
		}
		return null;
	}
}