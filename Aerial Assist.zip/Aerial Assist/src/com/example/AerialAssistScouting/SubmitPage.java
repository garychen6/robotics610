package com.example.AerialAssistScouting;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import com.example.scoutingapp610.R;

public class SubmitPage extends Activity {
	//Declare Score object
	Score scoutingTeam;
	//Declare defense variable
	int defence;
	//Declare TextView object
	TextView defenceLabel;
	//Declare SneekBar object
	SeekBar defenceRating;
	//Declare CheckBox objects
	CheckBox intake, herder, goalie, catcher, shooter;
	//Declare dialog object
	AlertDialog.Builder dialog;
	//Declare intent object
	Intent goToNextPage;
	
	static String prevName = "";
	EditText scouterName;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_submit_page);
		// Show the Up button in the action bar.
		setupActionBar();
		//Create dialog object
		dialog = new AlertDialog.Builder(this);
		//Create intent object
		goToNextPage = new Intent(this, FinalPage.class);
		//Get current Score instance
		scoutingTeam = Score.getInstance();
		//Assign defenceRating seek bar to its ID
		defenceRating = (SeekBar) findViewById(R.id.defenceRating);
		//Assign TextView to its ID
		defenceLabel = (TextView) findViewById(R.id.defenceLable);
		//Assign CheckBox objects to their IDs
		intake = (CheckBox) findViewById(R.id.intake);
		herder = (CheckBox) findViewById(R.id.herder);
		goalie = (CheckBox) findViewById(R.id.goalie);
		catcher = (CheckBox) findViewById(R.id.catching);
		shooter = (CheckBox) findViewById(R.id.shooter);
		scouterName = (EditText)findViewById(R.id.scouterName);
		scouterName.setText(prevName);
		
		//Set defenceRating progress to 0		
		defenceRating.setProgress(4);
		defenceLabel.setText("Defence Rating: 5");
		//Set defenceRating maximum value to 10
		defenceRating.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			//If progress was changed...
			@Override
			public void onProgressChanged(SeekBar arg0, int value, boolean arg2) {
				// TODO Auto-generated method stub
				//Set defence variable to seekBar value
				defence = value+1;
				//Set defenceLabel text
				if(defence != 1){
					defenceLabel.setText("Defence Rating: " + defence);
				}else{
					defenceLabel.setText("No defense");
				}
			}
			@Override
			public void onStartTrackingTouch(SeekBar arg0) {
				// TODO Auto-generated method stub

			}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {
				// TODO Auto-generated method stub

			}
		});
	}

	/**
	 * Set up the {@link android.app.ActionBar}, if the API is available.
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	private void setupActionBar() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			getActionBar().setDisplayHomeAsUpEnabled(true);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.submit_page, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// This ID represents the Home or Up button. In the case of this
			// activity, the Up button is shown. Use NavUtils to allow users
			// to navigate up one level in the application structure. For
			// more details, see the Navigation pattern on Android Design:
			//
			// http://developer.android.com/design/patterns/navigation.html#up-vs-back
			//
			// NavUtils.navigateUpFromSameTask(this);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	//If submit button was clicked...
	public void submit(View v) {
		//If defence rating is 0...
		if (defence == 0) {
			//Display error message
			dialog.setTitle("Error");
			dialog.setMessage("Defence Rating must be a number between 1 and 10");
			dialog.show();
		//If there is no name entered...
		} else if(scouterName.getText().toString().equals("")){
			//Display error message
			dialog.setTitle("Error");
			dialog.setMessage("Enter your name");
			dialog.show();
		} else {
			String curName = scouterName.getText().toString().replaceAll("\n", "");
			//Save scouter name
			scoutingTeam.setName(curName);
			prevName = curName;
			//Display confirm message
			dialog.setTitle("Confirm");
			dialog.setMessage("Submit defence/robot type data?");
			//Create positive button with text "Yes"
			dialog.setPositiveButton("Yes", new OnClickListener() {
				//If positive button is clicked
				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					// TODO Auto-generated method stub
					//Save all robot types
					scoutingTeam.setIntake(intake.isChecked());
					scoutingTeam.setShooter(shooter.isChecked());
					scoutingTeam.setHerder(herder.isChecked());
					scoutingTeam.setCatcher(catcher.isChecked());
					scoutingTeam.setGoalie(goalie.isChecked());
					scoutingTeam.defenceRating = defence;
					//Go to next activity(FinalPage)
					startActivity(goToNextPage);
				}
			});
			//Create negative button with text "No"
			dialog.setNegativeButton("No", null);
			dialog.show();
			//Create new dialog object to clear positive and negative buttons
			dialog = new AlertDialog.Builder(this);
		}
	}
	
	@Override
	public void onBackPressed(){
//		TeleOP.getInstance().populateCycles();
		super.onBackPressed();
	}
}