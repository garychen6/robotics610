package com.example.AerialAssistScouting;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.scoutingapp610.R;

public class CycleList extends LinearLayout{
	//Declare highMiss and lowMiss
	int highMiss, lowMiss;
	//Declare goalLocation variable
	int goalLocation;
	//Declare index counter
	int index;
	//Declare booleans
	boolean assist, trussGoal, catched;
	//Declare TextView objects
	TextView highMissView, lowMissView, goalLocationView, assistView, trussGoalView, catchedView;
	//Declare LinearLayout object
	LinearLayout parent;
	//Declare temporary Context object
	Context temp;

	public CycleList(Context context, final LinearLayout parent, int highMiss, int lowMiss, int goalLocation,
			boolean assist, boolean trussGoal, boolean catched) {
		super(context);
		//Set temp object to point to entered Context Object
		temp = context;
		//Mandatory code to run LinearLayout list
		LayoutInflater  inflater = LayoutInflater.from(context);
		inflater.inflate(R.layout.cycle_list, this, true);
		//Save highMiss value
		this.highMiss = highMiss;
		//Display highMiss value
		highMissView = (TextView)findViewById(R.id.cycleHighMiss);
		highMissView.setText("High Misses: " + highMiss);
		//Save lowMiss value
		this.lowMiss = lowMiss;
		//Display lowMiss value
		lowMissView = (TextView)findViewById(R.id.cycleLowMiss);
		lowMissView.setText("Low Misses: " + lowMiss);
		//Save goalLocation
		this.goalLocation = goalLocation;
		//Display goalLocation
		goalLocationView = (TextView)findViewById(R.id.cycleGoalLocation);
		switch(goalLocation){
		//If goalLocation was 0...
		case 0:
			goalLocationView.setText("Goal Location: Did not score");
			break;
		//If goalLocation was 1...
		case 1:
			goalLocationView.setText("Goal Location: Low");
			break;
		//If goalLocation was 10...
		case 10:
			goalLocationView.setText("Goal Location: High");
			break;
		default:
			break;
		}
		//Save assist value
		this.assist = assist;
		//Assign assistView to its assigned ID
		assistView = (TextView)findViewById(R.id.cycleAssist);
		//If robot got an assist
		if(assist){
			//Display TextView as green
			assistView.setBackgroundColor(Color.GREEN);
		}else{
			//Display TextView as red
			assistView.setBackgroundColor(Color.RED);
		}
		//Save trussGoal value
		this.trussGoal = trussGoal;
		//Assign trussGoal value to its assigned ID
		trussGoalView= (TextView)findViewById(R.id.cycleTruss);
		//If robot got a trussGoal
		if(trussGoal){
			//Display TextView as green
			trussGoalView.setBackgroundColor(Color.GREEN);
		}else{
			//Display TextView as red
			trussGoalView.setBackgroundColor(Color.RED);
		}
		//Save catched value
		this.catched = catched;
		//Assign catchedView to its assigned ID
		catchedView = (TextView)findViewById(R.id.cycleCatch);
		//If robot caught the ball after a truss goal...
		if(catched){
			//Display TextView as green
			catchedView.setBackgroundColor(Color.GREEN);
		}else{
			//Display TextView as red
			catchedView.setBackgroundColor(Color.RED);
		}
		//Save parent object
		this.parent = parent;
		//Add this CycleList object to the parent view
		parent.addView(this, 0);
		//Get deleteButton ID and set an OnClickListener
		((ImageButton)findViewById(R.id.deleteCycle)).setOnClickListener(new OnClickListener(){
			//If button was clicked...
			@Override
			public void onClick(View v) {
				//Declare and create dialog object
				AlertDialog.Builder dialog = new AlertDialog.Builder(temp);
				//Display confirm message
				dialog.setTitle("Confirm");
				dialog.setMessage("Delete this cycle?");
				//Create positive button with text "Yes"
				dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					//If positive button was clicked...
					public void onClick(DialogInterface dialog, int which) {
						//Remove this cycle from the list
						parent.removeView(CycleList.this);
						//Call TeleOp method deleteCycle
						TeleOP.deleteCycle(CycleList.this);
					}
				});
				//Create negative button with text "No"
				dialog.setNegativeButton("No", null);
				dialog.show();	
			}
		});
		Score.getList().add(0, this);
	}
	
	//Get highMiss variable
	public int getHighMiss() {
		return highMiss;
	}
	//Set highMiss variable
	public void setHighMiss(int highMiss) {
		this.highMiss = highMiss;
	}
	//Get lowMiss variable
	public int getLowMiss() {
		return lowMiss;
	}
	//Set lowMiss variable
	public void setLowMiss(int lowMiss) {
		this.lowMiss = lowMiss;
	}
	//Get goalLocation
	public int getGoalLocation() {
		return goalLocation;
	}
	//Set goalLocation
	public void setGoalLocation(int goalLocation) {
		this.goalLocation = goalLocation;
	}
	//Get assist value
	public boolean isAssist() {
		return assist;
	}
	//Set assist value
	public void setAssist(boolean assist) {
		this.assist = assist;
	}
	//Get trussGoal value
	public boolean isTrussGoal() {
		return trussGoal;
	}
	//Set trussGoal value
	public void setTrussGoal(boolean trussGoal) {
		this.trussGoal = trussGoal;
	}
	//Get trussGoal value
	public boolean isCatched() {
		return catched;
	}
	//Set trussGoal value
	public void setCatched(boolean catched) {
		this.catched = catched;
	}
	//Increment index
	public void incrementIndex() {
		index++;
		
	}
	//Decrement index
	public void decrementIndex(){
		index --;
	}
	//Delete this CycleList object
	public void deleteCycle(){
		parent.removeView(this);
	}
}
