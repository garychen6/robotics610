package com.example.AerialAssistScouting;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.example.scoutingapp610.R;

public class MainActivity extends Activity {

	public static String tournament = "tournament1";
	static Score scoutingTeam;
	ToggleButton scoreToggle, hotToggle, lowToggle, highToggle, noGoalToggle,
			mobilityToggle, goalieToggle, missToggle;
	EditText matchNumber, teamNumber;
	int goalValue;
	int autonScore = 0;
	AlertDialog.Builder dialog;
	Intent goToNextPage;
	Vibrator vibrate;
	int vibrateLength;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		vibrate = (Vibrator) getSystemService(VIBRATOR_SERVICE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		dialog = new AlertDialog.Builder(this);
		scoutingTeam = Score.getInstance();
		matchNumber = (EditText) findViewById(R.id.matchNumberInput);
		teamNumber = (EditText) findViewById(R.id.scoutingTeamInput);
		noGoalToggle = (ToggleButton) findViewById(R.id.noGoalToggle);
		lowToggle = (ToggleButton) findViewById(R.id.lowToggle);
		highToggle = (ToggleButton) findViewById(R.id.highToggle);
		mobilityToggle = (ToggleButton) findViewById(R.id.mobility);

		hotToggle = (ToggleButton) findViewById(R.id.hotGoal);
		goalieToggle = (ToggleButton) findViewById(R.id.goalieToggle);
		scoreToggle = (ToggleButton) findViewById(R.id.scoreToggle);
		missToggle = (ToggleButton) findViewById(R.id.missToggle);
		scoreToggle.setVisibility(View.INVISIBLE);
		hotToggle.setVisibility(View.INVISIBLE);
		missToggle.setVisibility(View.INVISIBLE);
		noGoalToggle.setBackgroundColor(Color.GREEN);
		lowToggle.setBackgroundColor(Color.RED);
		highToggle.setBackgroundColor(Color.RED);
		scoreToggle.setBackgroundColor(Color.GREEN);
		missToggle.setBackgroundColor(Color.RED);
		scoreToggle.setChecked(true);
		hotToggle.setBackgroundColor(Color.RED);
		mobilityToggle.setBackgroundColor(Color.RED);
		goalieToggle.setBackgroundColor(Color.RED);
		goToNextPage = new Intent(this, TeleOP.class);
		vibrateLength = 90;

		float batteryLife = getBatteryLevel();
		if (batteryLife <= 50) {
			vibrate.vibrate(new long[]{100,200,100,200,100,200,100,200,100,200,100,200,100,200},-1);
			Toast.makeText(getApplicationContext(), "Battery Low \nCharge the tablet",
					Toast.LENGTH_LONG).show();
			Toast.makeText(getApplicationContext(), "Battery Low \nCharge the tablet",
					Toast.LENGTH_SHORT).show();
		}
	}

	public float getBatteryLevel() {
		Intent batteryIntent = registerReceiver(null, new IntentFilter(
				Intent.ACTION_BATTERY_CHANGED));
		int level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
		int scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

		// Error checking that probably isn't needed but I added just in case.
		if (level == -1 || scale == -1) {
			return 50.0f;
		}

		return ((float) level / (float) scale) * 100.0f;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onBackPressed() {
	}

	public void noGoalClick(View v) {
		vibrate.vibrate(vibrateLength);
		noGoalToggle.setChecked(true);
		noGoalToggle.setBackgroundColor(Color.GREEN);
		lowToggle.setBackgroundColor(Color.RED);
		highToggle.setBackgroundColor(Color.RED);
		scoreToggle.setVisibility(View.INVISIBLE);
		scoreToggle.setChecked(true);
		scoreToggle.setBackgroundColor(Color.GREEN);
		missToggle.setVisibility(View.INVISIBLE);
		missToggle.setChecked(false);
		missToggle.setBackgroundColor(Color.GREEN);
		hotToggle.setVisibility(View.INVISIBLE);
		hotToggle.setBackgroundColor(Color.RED);
		hotToggle.setChecked(false);
		lowToggle.setChecked(false);
		highToggle.setChecked(false);
		goalValue = 0;

	}

	public void lowClick(View v) {
		vibrate.vibrate(vibrateLength);
		lowToggle.setChecked(true);
		scoreToggle.setVisibility(View.VISIBLE);
		hotToggle.setVisibility(View.INVISIBLE);
		missToggle.setVisibility(View.VISIBLE);
		scoreToggle.setBackgroundColor(Color.GREEN);
		hotToggle.setBackgroundColor(Color.RED);
		scoreToggle.setChecked(false);
		hotToggle.setChecked(false);
		noGoalToggle.setChecked(false);
		highToggle.setChecked(false);
		missToggle.setChecked(false);
		scoreToggle.setChecked(true);
		scoreToggle.setBackgroundColor(Color.GREEN);
		missToggle.setBackgroundColor(Color.RED);
		noGoalToggle.setBackgroundColor(Color.RED);
		lowToggle.setBackgroundColor(Color.GREEN);
		highToggle.setBackgroundColor(Color.RED);
		goalValue = 6;
	}

	public void highClick(View v) {
		vibrate.vibrate(vibrateLength);
		highToggle.setChecked(true);
		scoreToggle.setVisibility(View.VISIBLE);
		hotToggle.setVisibility(View.VISIBLE);
		missToggle.setVisibility(View.VISIBLE);
		scoreToggle.setChecked(true);
		scoreToggle.setBackgroundColor(Color.GREEN);
		hotToggle.setChecked(false);
		noGoalToggle.setChecked(false);
		lowToggle.setChecked(false);
		missToggle.setChecked(false);
		scoreToggle.setChecked(true);
		scoreToggle.setBackgroundColor(Color.GREEN);
		missToggle.setBackgroundColor(Color.RED);
		noGoalToggle.setBackgroundColor(Color.RED);
		lowToggle.setBackgroundColor(Color.RED);
		highToggle.setBackgroundColor(Color.GREEN);
		goalValue = 15;
	}

	public void scoreClick(View v) {
		vibrate.vibrate(vibrateLength);
		scoreToggle.setChecked(true);
		scoreToggle.setBackgroundColor(Color.GREEN);
		missToggle.setBackgroundColor(Color.RED);
		missToggle.setChecked(false);
	}

	public void missClick(View v) {
		vibrate.vibrate(vibrateLength);
		missToggle.setChecked(true);
		missToggle.setBackgroundColor(Color.GREEN);
		scoreToggle.setBackgroundColor(Color.RED);
		scoreToggle.setChecked(false);

	}

	public void hotClick(View v) {
		vibrate.vibrate(vibrateLength);
		if (hotToggle.isChecked()) {
			hotToggle.setBackgroundColor(Color.GREEN);
		} else {
			hotToggle.setBackgroundColor(Color.RED);
		}
	}

	public void mobilityClick(View v) {
		vibrate.vibrate(vibrateLength);
		if (mobilityToggle.isChecked()) {
			mobilityToggle.setBackgroundColor(Color.GREEN);
			goalieToggle.setBackgroundColor(Color.RED);
			goalieToggle.setChecked(false);
		} else {
			mobilityToggle.setBackgroundColor(Color.RED);
		}
	}

	public void goalieClick(View v) {
		vibrate.vibrate(vibrateLength);
		if (goalieToggle.isChecked()) {
			goalieToggle.setBackgroundColor(Color.GREEN);
			mobilityToggle.setChecked(false);
			mobilityToggle.setBackgroundColor(Color.RED);
		} else {
			goalieToggle.setBackgroundColor(Color.RED);
		}
	}

	public void nextPage(View v) {
		if (matchNumber.getText().toString().equals("")
				|| teamNumber.getText().toString().equals("")) {
			dialog.setTitle("Error");
			dialog.setMessage("Invalid Team Number or Match Number");
			dialog.show();
		} else {
			vibrate.vibrate(vibrateLength);
			dialog.setTitle("Confirm");
			dialog.setMessage("Submit autonomous mode data?");
			dialog.setPositiveButton("Yes", new OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					autonScore += goalValue;
					scoutingTeam.autonShotLocation(goalValue);
					if (hotToggle.isChecked() && scoreToggle.isChecked()) {
						autonScore += 5;
					}
					if (mobilityToggle.isChecked()) {
						autonScore += 5;
					}
					scoutingTeam.autonMissed(missToggle.isChecked());
					scoutingTeam.autonScored(scoreToggle.isChecked());
					scoutingTeam.autonHotGoal(hotToggle.isChecked());
					scoutingTeam.goalieStart(goalieToggle.isChecked());
					scoutingTeam.mobility(mobilityToggle.isChecked());
					scoutingTeam.matchNumber(Integer.parseInt(matchNumber
							.getText().toString()));
					scoutingTeam.setTeamNumber(Integer.parseInt(teamNumber
							.getText().toString()));
					scoutingTeam.setAutonScore(autonScore);
					startActivity(goToNextPage);
				}
			});
			dialog.setNegativeButton("No", null);
			dialog.show();
		}
	}
}
